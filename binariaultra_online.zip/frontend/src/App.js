
import React from "react";

function App() {
  return (
    <div style={{ textAlign: "center", marginTop: "2rem" }}>
      <h1>BinariaUltra Online</h1>
      <p>Frontend conectado.</p>
    </div>
  );
}

export default App;
