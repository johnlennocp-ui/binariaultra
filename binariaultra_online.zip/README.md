# BinariaUltra Online

Este é um exemplo mínimo para testes no Glitch/Replit com API + React.